﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FutureAgro.DataAccess.Services
{
    public class UserService : IUserService
    {
    }
}
